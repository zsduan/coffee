module.exports = {
  publicPath: './'
}
