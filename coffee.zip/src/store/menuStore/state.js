export const state = {

  //缓存菜单数据

  //banner数据
  bannerDataCache: [],
  // 选择数据
  option1Cache:[]

}