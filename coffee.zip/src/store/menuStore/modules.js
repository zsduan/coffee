import {state} from './state'

import {mutations} from './mutations'

export const menuModule = {
  namespaced: true,
  state,
  mutations
}